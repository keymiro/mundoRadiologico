<?php $__env->startSection('content'); ?>
 <!-- ======= Top Bar ======= -->
 <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</br></br></br></br>
  <main id="main">
    <!-- ======= Doctors Section ======= -->
    <section id="doctors" class="doctors">
        <div class="container">

          <div class="section-title">
            <h2> <a href="">Médicos</a></h2>

          </div>

          <div class="row">
            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i->category->title=='medico'): ?>
            <div class="col-lg-6 mt-4 mt-lg-0">
                <div class="member d-flex align-items-start shadow">
                  <div class="pic"><img src="<?php echo e(Storage::url($i->url)); ?>" class="img-fluid" alt=""></div>
                  <div class="member-info">
                    <h4><?php echo e($i->title); ?></h4>
                    <p><?php echo e($i->description); ?></p>
                  </div>
                </div>
              </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

        </div>
      </section><!-- End Doctors Section -->

    </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/medicos.blade.php ENDPATH**/ ?>