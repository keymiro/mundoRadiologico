<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-white bg-dark">
                <div class="card-header"><?php echo e(__('Listado de Secciones')); ?></div>

                <div class="card-body">
                    <a href="<?php echo e(route('info.create')); ?>" class="btn btn-primary">Nueva sección</a>

                    <div class="my-4">
                        <table class="table table-striped table-dark table-responsive-sm table-sm">
                            <thead>
                              <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Categoría</th>
                                <th scope="col">Creado por</th>
                                <th scope="col">Acciones</th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($inf->title); ?></td>
                                <td><?php echo e($inf->category->title); ?></td>
                                <td><?php echo e($inf->user->name); ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="<?php echo e(route('info.edit',$inf->id)); ?>" type="button" class="btn btn-secondary">Editar</a>
                                        <form   action="<?php echo e(route('info.delete',$inf->id)); ?>"
                                            method="post">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button  class="btn btn-danger" onclick="return confirm('Estás seguro que desea eliminar el registro?');">
                                           Eliminar
                                        </button>
                                    </form>
                                      </div>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                          <?php echo e($info->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/info/index.blade.php ENDPATH**/ ?>