<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mensaje recibido</title>
</head>
<body>
    <p>Recibiste un mensaje de : <?php echo e($msg['name']); ?></p>
    <p><Strong>Documento: <?php echo e($msg['document']); ?></Strong></p>
    <p><Strong>Email: <?php echo e($msg['email']); ?></Strong></p>
    <p><Strong>Movil: <?php echo e($msg['phone']); ?></Strong></p>
    <p><Strong>Ciudad: <?php echo e($msg['city']); ?></Strong></p>
    <p><Strong>Fecha de nacimiento: <?php echo e($msg['datehb']); ?></Strong></p>
    <p><Strong>Dirección: <?php echo e($msg['direction']); ?></Strong></p>
    <p><Strong>Fecha de la cita: <?php echo e($msg['date']); ?></Strong></p>
    <p><Strong>Jornada: <?php echo e($msg['workingday']); ?></Strong></p>
    <p>Contenido: <?php echo e($msg['message']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/emails/cita.blade.php ENDPATH**/ ?>