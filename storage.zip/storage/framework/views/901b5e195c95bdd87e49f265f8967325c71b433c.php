<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-white bg-dark">
                <div class="card-header"><?php echo e(__('Listado de categorias')); ?></div>

                <div class="card-body">
                    <a href="<?php echo e(route('info.createCategory')); ?>" class="btn btn-primary">Nueva categoría</a>

                    <div class="my-4">
                        <table class="table table-striped table-dark table-responsive-sm table-sm">
                            <thead>
                              <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Acciones</th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($c->title); ?></td>
                                <td><?php echo e($c->description); ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="<?php echo e(route('info.editCategory',$c->id)); ?>" type="button" class="btn btn-secondary">Editar</a>
                                        <form   action="<?php echo e(route('info.deleteCategory',$c->id)); ?>"
                                            method="post">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button  class="btn btn-danger" onclick="return confirm('Estás seguro que desea eliminar el registro?');">
                                           Eliminar
                                        </button>
                                    </form>
                                      </div>
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                          <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/info/index_category.blade.php ENDPATH**/ ?>