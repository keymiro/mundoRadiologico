<?php $__env->startSection('content'); ?>
 <!-- ======= Top Bar ======= -->
 <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</br></br></br></br>
  <main id="main">
    <!-- ======= Services Section ======= -->
<section id="services" class="services">
    <div class="container">
        <div class="section-title">
            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i->category->title=='servicios'): ?>
                <h2><a href=""><?php echo e($i->title); ?></a></h2>
                <p class="description"><?php echo e($i->description); ?></p>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row">
            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i->category->title=='services'): ?>
                <div class="col-lg-4 col-md-6 d-flex align-items-stretch  mt-4">
                    <div class="icon-box">
                            <div class="icon"><img class="img-fluid" src="<?php echo e(asset($i->url)); ?>" alt=""></div>
                            <h4><a href=""><?php echo e($i->title); ?></a></h4>
                            <p><?php echo $i->descriptionck; ?></p>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><!-- End Services Section -->
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/servicios.blade.php ENDPATH**/ ?>