<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-white bg-dark">
                <div class="card-header"><?php echo e(__('Nueva categoría')); ?></div>

                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(route('info.indexCategory')); ?>" class="btn btn-primary">Listado de categorias</a>
                    </div>
                    <form action="<?php echo e(route('info.storeCategory')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="title">Titulo</label>
                            <input type="text" class="form-control" name="title" id="title" placeholder="Título">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Descripcción</label>
                            <textarea class="form-control" id="description" name="description" rows="3" placeholder="Descripción"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/info/create_category.blade.php ENDPATH**/ ?>