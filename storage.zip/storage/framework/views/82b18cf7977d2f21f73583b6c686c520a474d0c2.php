<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card text-white bg-dark">
                <div class="card-header"><?php echo e(__('Nueva sección')); ?></div>
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(route('info.home')); ?>" class="btn btn-primary">Listado de Secciones</a>
                    </div>
                <form action="<?php echo e(route('info.update',$info->id)); ?>"  method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                        <label for="title">Titulo</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Título" required value="<?php echo e($info->title); ?>">
                      </div>
                    <div class="mb-3">
                        <label for="">Categoría</label>
                        <select class="form-select form-control" aria-label="Default select example" name="category" required>
                            <option selected value="<?php echo e($info->category->id); ?>"><?php echo e($info->category->title); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($c->id); ?>"><?php echo e($c->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="inputGroupFileAddon01">Imagen</span>
                        </div>
                        <div class="custom-file">
                          <input type="file" name="file"class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01" value="<?php echo e($info->url); ?>">
                          <label class="custom-file-label" for="inputGroupFile01"><?php echo e($info->url); ?></label>
                        </div>
                      </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Descripción</label>
                        <textarea class="form-control" id="description" rows="3" placeholder="Descripción" name="description"><?php echo e($info->description); ?>

                        </textarea>
                    </div>
                    <div class="mb3">
                        <a class="btn btn-primary mr-2" data-toggle="collapse" href="#multiCollapseExample1" role="button">Más</a>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <div class="collapse multi-collapse" id="multiCollapseExample1">
                            <hr>
                           <textarea class="form-control" id="summary-ckeditor" name="summary-ckeditor"><?php echo e($info->descriptionck); ?>

                           </textarea>
                    </div>
                </div>
               </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<script>
   CKEDITOR.replace( 'summary-ckeditor', {
    filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
    filebrowserUploadMethod: 'form'
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/info/edit.blade.php ENDPATH**/ ?>