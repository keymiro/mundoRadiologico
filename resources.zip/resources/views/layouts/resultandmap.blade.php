
<center>
  <div class="row">
  <button id="resul" type="button" class="btn  rounded " data-toggle="modal" data-target="#encuesta">
        <img src="image/17.png" alt="" id="res" >
    </button>
  </div>
  <br>
  <br>
    <div class="row">
    <a id="map" href="https://www.google.com/maps/place/Mundo+radiologico/@5.346449,-72.395959,18z/data=!4m5!3m4!1s0x0:0x2b3d9685eb29917c!8m2!3d5.3464486!4d-72.3959594?hl=es">
      <img src="image/18.png" alt="Map" id="map1"  class="shadow">
    </a>
    </div>

</center>

