$( document ).ready(function() {
    $('#staticBackdrop').modal('toggle')
});