<?php $__env->startSection('content'); ?>
 <!-- ======= Top Bar ======= -->
 <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</br></br></br></br>
  <main id="main">
<section id="dd" class="testimonials">
    <div class="container">
        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="accordion" id="accordionPanelsStayOpenExample">
                    <div class="section-title">
                                    <h2>Estados Financieros</h2>
                                </div>
                    <div class="accordion accordion-flush" id="DatosInteres" >
<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PED): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($PED->category->title=='PreparacionExtamenesDiagnosticos'): ?>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-heading<?php echo e($PED->id); ?>">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($PED->id); ?>" aria-expanded="false" aria-controls="flush-collapseOne">
      <p><?php echo e($PED->title); ?></p>
      </button>
    </h2>
    <div id="flush-collapse<?php echo e($PED->id); ?>" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body"><p><?php echo $PED->descriptionck; ?></p></div>
    </div>
  </div>
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
                    </div>
                </div>
           </div>
        </div>
    </div>
</section><!-- End Testimonials Section -->
  </main>
 <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundoRadiologico\resources\views/finan.blade.php ENDPATH**/ ?>